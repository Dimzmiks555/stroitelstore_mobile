CORSify a folder in Apache
==========================

Add the above three lines to an `.htaccess` file to enable CORS for that folder and its subfolders. Of course, you could also add this to the `httpd.conf` file if you have access.

###Notes:
* Ensure that the [mod_headers](http://httpd.apache.org/docs/current/mod/mod_headers.html) Apache Module is enabled.
* This will open things up pretty grandly. This may or may not be what you want.

###Disclaimer
* Do at your own risk, etc. etc.
* My Apache-fu is weak, so there may well be a better solution.
